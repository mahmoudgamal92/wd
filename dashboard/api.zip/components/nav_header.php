<div class="nav-header">
			<a href="index.php" class="brand-logo">
				<img class="logo-abbr" src="images/logo.png" style="width:80px;height:80px">
			</a>

			<div class="nav-control">
				<div class="hamburger">
					<span class="line"></span>
					<span class="line"></span>
					<span class="line"></span>
				</div>
			</div>
		</div>