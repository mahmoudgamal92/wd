<footer class="bdT ta-c p-30 lh-0 fsz-sm c-grey-600">
  <span>Copyright © 2022 Developed by 
    <a href="#" target="_blank" title="Stakfort">Aqartech</a>. All rights reserved.</span>
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag() { dataLayer.push(arguments); }
          gtag('js', new Date());
          gtag('config', 'UA-23581568-13');
        </script>
      </footer>